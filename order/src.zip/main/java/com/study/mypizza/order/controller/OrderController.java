package com.study.mypizza.order.controller;

import com.study.mypizza.order.dto.ItemDto;
import com.study.mypizza.order.dto.OrderDetailDto;
import com.study.mypizza.order.dto.OrderRequestDto;
import com.study.mypizza.order.exception.MyPizzaException;
import com.study.mypizza.order.service.ItemService;
import com.study.mypizza.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
@Slf4j
public class OrderController {
    private final OrderService orderService ;
    private final ItemService itemService ;

    @GetMapping("/main")
    public String getItems(Model model) {
        List<ItemDto> itemDtos = itemService.getItems() ;
        model.addAttribute("itemDtos", itemDtos);
        model.addAttribute("customerId", "1");
        model.addAttribute("regionNm", "강남구");
        return "main";
    }

    @PostMapping("/orders")
    public ResponseEntity<String> createOrder(@RequestBody OrderRequestDto orderRequestDto) {
        List<OrderDetailDto> orderDetailDtos = orderService.createOrder(orderRequestDto) ;
        return ResponseEntity.ok("{\"msg\":\"주문이 완료되었습니다!\"}") ;
    }

    @PatchMapping("/orders/orderCancel/{orderId}")
    public String orderCancel(@PathVariable("orderId") Long orderId) throws MyPizzaException {
        orderService.orderCancel(orderId);
        return "취소되었습니다." ;
    }
}
