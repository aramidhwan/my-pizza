package com.study.mypizza.order.eventHandler;

import com.study.mypizza.order.entity.Order;
import com.study.mypizza.order.repository.OrderRepository;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.Optional;
import java.util.function.Consumer;

@Service
@Slf4j
public class EventHandler {
    @Autowired
    OrderRepository orderRepository;

    @Bean
    @Transactional
    public Consumer<Message<String>> whenever_storeEvent_updateStatus() {
        return message -> {
            String jsonString = message.getPayload() ;
            JSONObject json = new JSONObject(jsonString);
            log.debug("### [{}] event received..!! : {}", new Object(){}.getClass().getEnclosingMethod().getName(), jsonString);
            Long orderId = json.getLong("orderId");
            String status = json.getString("status");
            setBusiness("상태업데이트");

            Optional<Order> orderOptional = orderRepository.findById(orderId) ;
            if ( orderOptional.isPresent()) {
                Order order = orderOptional.get();

                // 중복처리 방지
                if ("OrderAccepted".equals(status) && !"Ordered".equals(order.getStatus())) {
                    log.debug("### [{}] event 상태이상!!, Skip..!! : orderId={}, status={}, currentStatus={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, status, order.getStatus());
                    return ;
                } else if ("Cooked".equals(status) && !"OrderAccepted".equals(order.getStatus())) {
                    log.debug("### [{}] event 상태이상!!, Skip..!! : orderId={}, status={}, currentStatus={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, status, order.getStatus());
                    return ;
                }

                order.setStatus(status);
                try {
                    order.setStoreId(json.getLong("storeId"));
                } catch (NumberFormatException | JSONException ex) {
                    // do noting
                }
                orderRepository.save(order);
            }
        } ;
    }

    private void setBusiness(String 신규주문) {
    }

    @Bean
    @Transactional
    public Consumer<Message<String>> whenever_deliveryEvent_updateStatus() {
        return message -> {
            String jsonString = message.getPayload() ;
            JSONObject json = new JSONObject(jsonString);
            Long orderId = json.getLong("orderId");
            String status = json.getString("status");

            Optional<Order> orderOptional = orderRepository.findById(orderId) ;
            if ( orderOptional.isPresent()) {
                Order order = orderOptional.get();

                // 중복처리 방지
                if ("DeliveryAccepted".equals(status) && !"Cooked".equals(order.getStatus())) {
                    log.debug("### [{}] event 상태이상!!, Skip..!! : orderId={}, status={}, currentStatus={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, status, order.getStatus());
                    return ;
                } else if ("DeliveryStarted".equals(status) && !"DeliveryAccepted".equals(order.getStatus())) {
                    log.debug("### [{}] event 상태이상!!, Skip..!! : orderId={}, status={}, currentStatus={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, status, order.getStatus());
                    return ;
                } else if ("Delivered".equals(status) && !"DeliveryStarted".equals(order.getStatus())) {
                    log.debug("### [{}] event 상태이상!!, Skip..!! : orderId={}, status={}, currentStatus={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, status, order.getStatus());
                    return ;
                }

                log.debug("### [{}] event received..!! : orderId={}, status={}", new Object(){}.getClass().getEnclosingMethod().getName(), orderId, order.getStatus());
                order.setStatus(status);
                orderRepository.save(order);
            }
        } ;
    }
}
