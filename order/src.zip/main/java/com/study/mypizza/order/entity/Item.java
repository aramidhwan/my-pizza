package com.study.mypizza.order.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Entity
@Table(name="t_item")
@Builder
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class Item {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="item_id")
    private Long itemId;
    private String itemNm;
    private String itemGroup;
    private Integer pricePerOne;
    private Date registDt;

    @PrePersist
    public void prePersist() {
        this.registDt = new Date();
    }
}

