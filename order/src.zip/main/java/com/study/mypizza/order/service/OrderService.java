package com.study.mypizza.order.service;

import com.study.mypizza.order.dto.ItemDto;
import com.study.mypizza.order.dto.OrderDetailDto;
import com.study.mypizza.order.dto.OrderDto;
import com.study.mypizza.order.dto.OrderRequestDto;
import com.study.mypizza.order.entity.Item;
import com.study.mypizza.order.entity.Order;
import com.study.mypizza.order.entity.OrderDetail;
import com.study.mypizza.order.exception.MyPizzaException;
import com.study.mypizza.order.external.StoreService;
import com.study.mypizza.order.repository.ItemRepository;
import com.study.mypizza.order.repository.OrderDetailRepository;
import com.study.mypizza.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class OrderService {

    private final OrderRepository orderRepository ;
    private final ItemRepository itemRepository;
    private final OrderDetailRepository orderDetailRepository;
    private final StoreService storeService ;

    @Transactional(rollbackFor = MyPizzaException.class)
    public void orderCancel(Long orderId) throws MyPizzaException {
        String rtnMsg = null ;
        Order order = orderRepository.findById(orderId)
                .orElseThrow(()-> new MyPizzaException("해당 하는 주문이 없습니다. : " + orderId)) ;

        // 주문 접수 이전 단계에서만 취소가능
        if ( "Ordered".equals(order.getStatus()) ) {
            // 취소 전에 주문받은 Store가 있는지 Store MSA에서 다시 한 번 체크
            if (storeService.checkOrderCancel(orderId)) {
                order.setStatus("OrderCancelled");
                orderRepository.save(order) ;
                // 취소 불가능
            } else {
                throw new MyPizzaException("### 주문 취소 불가능 :: 이미 Store에서 준비중입니다.");
            }
        } else {
            // 취소 불가능
            throw new MyPizzaException("### 주문 취소 불가능 :: 주문취소 불가능 단계("+order.getStatus()+") 입니다.") ;
        }
    }

    @Transactional
    public List<OrderDetailDto> createOrder(OrderRequestDto orderRequestDto) throws MyPizzaException {
        List<OrderDetailDto> orderDetailDtos = new ArrayList<>();
        List<OrderDetail> orderDetails = null ;
        OrderDetailDto orderDetailDto = null;
        BigDecimal totalPricefromDB = new BigDecimal(0);
        
        // Req/Res Calling
        // 주문 요청된 지역에 오픈중인 Store가 있는지 체크
        String openYN = storeService.checkOpenYn(orderRequestDto.getRegionNm()) ;

        Order newOrder = Order.builder()
                .customerId(orderRequestDto.getCustomerId())
                .status("Y".equals(openYN)? "Ordered":"OrderRejected")
                .statusInfo("Y".equals(openYN)? "Ordered":"N".equals(openYN)? "OrderRejected::[" + orderRequestDto.getRegionNm() + "] 지역에 영업중인 Store가 없습니다.":"OrderRejected::"+openYN)
                .regionNm(orderRequestDto.getRegionNm())
                .totalPrice(orderRequestDto.getTotalPrice())
                .orderDt(new Date())
                .build();
        newOrder = orderRepository.save(newOrder);

        List<ItemDto> items = orderRequestDto.getItems();
        List<Long> itemIds = new ArrayList<>();
        for (ItemDto itemDto : items) {
            itemIds.add(itemDto.getItemId());
        }
        List<ItemDto> itemDtosFromDB = itemRepository.findByItemIdIn(itemIds)
                .stream()
                .map(ItemDto::of)
                .toList();
        for (ItemDto itemDto : items) {
            Item item = itemRepository.findById(itemDto.getItemId())
                    .orElseThrow(() -> new RuntimeException("존재하지 않는 품목입니다. ITEM_ID=["+itemDto.getItemId()+"]"));
            totalPricefromDB = totalPricefromDB.add(new BigDecimal(item.getPricePerOne()).multiply(new BigDecimal(itemDto.getQty())));
            orderDetailDtos.add(OrderDetailDto.builder()
                    .orderDto(OrderDto.of(newOrder))
                    .itemDto(itemDto)
                    .qty(itemDto.getQty())
                    .pricePerOne(item.getPricePerOne())
                    .registDt(new Date())
                    .build()
            );
        }

        // DB에 저장되어 계산된 Total 가격과 Parameter로 넘어온 Total 가격이 다를 경우 예외 발생
        if ( totalPricefromDB.intValue() != newOrder.getTotalPrice() ) {
//            newOrder.setTotalPrice(totalPricefromDB.intValue());
//            orderRepository.save(newOrder);
            throw new MyPizzaException("Total 가격이 다릅니다. 계산된 가격 = ["+totalPricefromDB.intValue()+"], Parameter 가격 = ["+newOrder.getTotalPrice()+"]") ;
        }
        
        // 주문 상세 내역 저장
        orderDetails = orderDetailRepository.saveAll(
                orderDetailDtos
                .stream()
                .map(OrderDetailDto::toEntity)
                .collect(Collectors.toList())
        ) ;

        // 주문 거절 시 사유 리텅
        // Exception으로 처리 시 DB 저장이 안됨
//        if ( !"Ordered".equals(newOrder.getStatus()) ) {
//            throw new MyPizzaException(newOrder.getStatusInfo()) ;
//        }

        return orderDetails.stream().map(OrderDetailDto::of).collect(Collectors.toList());
    }
}
