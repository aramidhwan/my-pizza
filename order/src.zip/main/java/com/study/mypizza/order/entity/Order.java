package com.study.mypizza.order.entity;

import com.study.mypizza.order.OrderApplication;
import com.study.mypizza.order.event.OrderCancelled;
import com.study.mypizza.order.event.OrderRejected;
import com.study.mypizza.order.event.Ordered;
import com.study.mypizza.order.event.StatusUpdated;
import jakarta.persistence.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import java.util.Calendar;
import java.util.Date;

@Entity
@Table(name="t_order")
@Builder
@Getter
@Setter
@NoArgsConstructor(force = true, access = AccessLevel.PROTECTED)
@AllArgsConstructor
@ToString
@Slf4j
public class Order {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="order_id")
    private Long orderId;
    private Long customerId;
    private Long storeId;
    private String status;
    private String statusInfo;
    private String regionNm;
    private Integer totalPrice;
    private Date orderDt;

    public void setStatus(String status) {
        this.status = status ;
        setStatusInfo(status);
    }

    public void setStatusInfo(String statusInfo) {
        if ( statusInfo != null ) {
            if (this.statusInfo != null) {
                this.statusInfo = this.statusInfo + "::" + statusInfo;
            } else {
                this.statusInfo = statusInfo;
            }
        }
    }

    @PostPersist
    private void onPostPersist() {
//        log.debug("### {} :: {}", this.getClass().getSimpleName(), new Object(){}.getClass().getEnclosingMethod().getName());
        if ( "Ordered".equals(this.status)) {
            Ordered ordered = new Ordered() ;
            BeanUtils.copyProperties(this, ordered);
            ordered.publishAfterCommit();
            log.debug("#### Published in [{}.{}()] : {}", this.getClass().getSimpleName(), new Object(){}.getClass().getEnclosingMethod().getName(), ordered.toString());
        } else if ( "OrderRejected".equals(this.status)) {
            OrderRejected orderRejected = new OrderRejected();
            BeanUtils.copyProperties(this, orderRejected);
            orderRejected.publishAfterCommit();
            log.debug("#### Published in [{}.{}()] : {}", this.getClass().getSimpleName(), new Object(){}.getClass().getEnclosingMethod().getName(), orderRejected.toString());
        }

    }

    @PostUpdate
    private void onPostUpdate() {
        if ( "Cooked".equals(this.status)) {
            if ( "Ordered::Cooked".equals(this.statusInfo)) {
                log.debug("#### onPostUpdate 333 [{}.{}()] : {}", this.getClass().getSimpleName(), new Object() {
                }.getClass().getEnclosingMethod().getName(), this.toString());
                try {
                    throw new Exception("AAAAAAAAAAAAAAAAA");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        // 모든 status 상태 변화 시 이벤트 발행
        StatusUpdated statusUpdated = new StatusUpdated();
        BeanUtils.copyProperties(this, statusUpdated);
        statusUpdated.publishAfterCommit();
        log.debug("#### Published in= [{}.{}()] : {}", this.getClass().getSimpleName(), new Object(){}.getClass().getEnclosingMethod().getName(), statusUpdated.toString());
    }
}
