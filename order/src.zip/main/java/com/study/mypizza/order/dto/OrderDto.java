package com.study.mypizza.order.dto;

import com.study.mypizza.order.entity.Order;
import com.study.mypizza.order.event.OrderRejected;
import com.study.mypizza.order.event.Ordered;
import com.study.mypizza.order.event.StatusUpdated;
import jakarta.persistence.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import java.util.Date;
import java.util.List;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Slf4j
public class OrderDto {

    private Long orderId;
    private Long customerId;
    private Long storeId;
    private String regionNm;
    private List<ItemDto> itemDtos;
    private String status;
    private String statusInfo;
    private Integer totalPrice;
    private Date orderDt;

    public Order toEntity() {
        return Order.builder()
                .orderId(orderId)
                .customerId(customerId)
                .storeId(storeId)
                .status(status)
                .statusInfo(statusInfo)
                .regionNm(regionNm)
                .totalPrice(totalPrice)
                .orderDt(orderDt)
                .build();
    }

    public static OrderDto of(Order order) {
        return OrderDto.builder()
                .orderId(order.getOrderId())
                .customerId(order.getCustomerId())
                .storeId(order.getStoreId())
                .status(order.getStatus())
                .statusInfo(order.getStatus())
                .regionNm(order.getRegionNm())
                .totalPrice(order.getTotalPrice())
                .orderDt(order.getOrderDt())
                .build();
    }
}
