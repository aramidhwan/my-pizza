package com.study.mypizza.order.controller;

import com.study.mypizza.order.exception.MyPizzaException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.security.SignatureException;
import java.util.Arrays;

@RestControllerAdvice
@Slf4j
public class ExceptionController {
    @ExceptionHandler(SignatureException.class)
    public ResponseEntity<Object> handleSignatureException(final SignatureException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("토큰이 변조되었습니다.");
    }
    
    @ExceptionHandler(SecurityException.class)
    public ResponseEntity<Object> handleSecurityException(final SecurityException ex) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("토큰이 유효하지 않습니다.");
    }

//    @ExceptionHandler(MalformedJwtException.class)
//    public ResponseEntity<Object> handleMalformedJwtException(final MalformedJwtException ex) {
//        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("올바르지 않은 토큰입니다.");
//    }
//
//    @ExceptionHandler(ExpiredJwtException.class)
//    public ResponseEntity<Object> handleExpiredJwtException(final ExpiredJwtException ex) {
//        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("토큰이 만료되었습니다. 다시 로그인해주세요.");
//    }
//
//    @ExceptionHandler(DuplicateMemberException.class)
//    public ResponseEntity<Object> handleDuplicateMemberException(final DuplicateMemberException ex) {
//        log.warn("### ExceptionController.handleDuplicateMemberException : {}", ex.getMessage());
//        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ex.getMessage());
//    }
//
//    // 401
//    @ExceptionHandler(AccessDeniedException.class)
//    public ResponseEntity<Object> handleAccessDeniedException(final AccessDeniedException ex) {
//        log.warn("### ExceptionController.handleAccessDeniedException : {}", ex.getMessage());
//        log.trace(Arrays.toString(ex.getStackTrace()));
//        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("접근 권한이 없습니다. 관리자에게 문의하세요. "+ex.getMessage());
//    }

    // 500
    @ExceptionHandler(MyPizzaException.class)
    public ResponseEntity<Object> handleMyPizzaException(final MyPizzaException ex) {
        log.debug("### ExceptionController.handleMyPizzaException : {}", ex.getMessage());
        return ResponseEntity.ok("{\"msg\": \""+ex.getMessage().replace('"','\'')+"\"}");
    }

    // 400
    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Object> handleRuntimeException(final RuntimeException ex) {
        log.warn("### ExceptionController.handleRuntimeException : {}", ex.getMessage());
        log.error("error", ex);
        return ResponseEntity.badRequest().body("{\"msg\": \"관리자에게 문의하십시요. : "+ex.getMessage().replace('"','\'')+"\"}");
    }

    // 500
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAll(final Exception ex) {
        log.error("### ExceptionController.handleAll : {}", ex.getMessage());
        log.error("error", ex);
        return new ResponseEntity<>("{\"msg\": \"관리자에게 문의하십시요. : "+ex.getMessage().replace('"','\'')+"\"}", HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
