package com.study.mypizza.order.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Entity
@Table(name="t_orderdetail")
@Builder
@Getter
@ToString
@NoArgsConstructor(force = true, access = AccessLevel.PROTECTED)
@AllArgsConstructor
@Slf4j
public class OrderDetail {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long orderDetailId;
    @ManyToOne
    @JoinColumn(name = "order_id", foreignKey = @ForeignKey(name = "fk_orderdetail_order_id"))
    @Builder.Default
    private Order order = new Order();
    @ManyToOne
    @JoinColumn(name = "item_id", foreignKey = @ForeignKey(name = "fk_orderdetail_item_id"))
    @Builder.Default
    private Item item = new Item();
    private Integer qty;
    private Integer pricePerOne;
    private Date registDt;
}
